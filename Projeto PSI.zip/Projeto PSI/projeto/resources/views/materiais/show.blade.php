@extends('layout')
@section('nabvar')
@endsection
@section('menu')
@endsection

@section('conteudo')
ID:{{$material->id_material}}<br>
Titulo:{{$material->designacao}}<br>

<h1>Requisicoes:</h1>

@foreach($material->requisicoes as $requisicao)
<h1> Hora de requisicao: </h1>
{{$requisicao->hora_requisicao}}
<h1> hora de entrega: </h1>
{{$requisicao->hora_entrega}}
<h1> Observacoes: </h1>
{{$requisicao->observacoes}}

@endforeach

@endsection

@section('rodapé')

@endsection
