@extends('layout')
@section('nabvar')
@endsection
@section('menu')
@endsection

@section('conteudo')

ID:{{$requisicao->id_requisicao}}<br>
Titulo:{{$requisicao->observacoes}}<br>
<h1><i>Requisitantes:</h1></i>
@foreach($requisicao->requisitantes as $requisitante)
<h2> Nome: </h2>
<h5>{{$requisitante->nome}}</h5>
<h2> Telefone: </h2>
<h5>{{$requisitante->telefone}}</h5>
<h2>Email: </h2>
<h5>{{$requisitante->email}}</h5>
<h2> Localidade: </h2>
<h5>{{$requisitante->localidade}}</h5>
@endforeach

@endsection

@section('rodapé')

@endsection





	