
<ul>
@foreach($tipos_equipamentos as $TipoEquip)
<li>
<a href="{{route('TiposEquips.show', ['id'=>$TipoEquip->id_tipo_equipamento])}}">
 {{$TipoEquip->nome}}</a></li>
@endforeach
</ul>
{{$TiposEquips->render()}}


