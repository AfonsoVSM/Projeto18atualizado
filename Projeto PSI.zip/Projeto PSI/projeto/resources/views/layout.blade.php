<!DOCTYPE html>
<html>
<head>
    @yield('navbar')
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0, shrink-to-fit-no" name="viewport">

	<title>Exemplo de Bootsrap</title>

<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">
<script src="{{asset('js/jquery-3.5.1.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
</head>

<body>
    <!--barra de navegação-->
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand" href="http://localhost/materiais"><b><FONT COLOR="#AA0000">Projecto PSI</FONT></b></a>
        <button class="navbar-toggler"type="button"data-toogle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"aria-expanded="false" aria-label="Toogle navigation">
        <span class="navbar-tooggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse"id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
            <a class="nav-link" href="{{route('materiais.index')}}"><b><FONT COLOR="#00AA00">Materiais</FONT></b><span class="sr-only">(atual)</span>
                </a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('requisicoes.index')}}"><b><FONT COLOR="#00AA00">Requisicoes</FONT></b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('requisitantes.index')}}"><b><FONT COLOR="#00AA00">Requisitantes</FONT></b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('TiposRequisitantes.index')}}"><b><FONT COLOR="#00AA00"></FONT></b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('TiposEquips.index')}}"><b><FONT COLOR="#00AA00"></FONT></b></a>
            </li>
            
            <li class="nav-item dropdown">

                

                <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="#">Item</a>
                 <a class="dropdown-item" href="#">Outro item</a>
                <a class="dropdown-item" href="#">Algum outro item</a>
                </div>
            </li>
            </ul>
    
        </div>
    </nav>

    @yield('menu')
    <main role="main">
        
    <div class="jumbotron">
        <div class="container">
             <div class="text-center">
        <h1 class="display-3"><FONT COLOR="#00AA00">Projeto Modulo 18</FONT></h1>
            
        <p><FONT COLOR="#0000AA">Afonso Valente / Nº1 / 12I2</p>
           
              <br>
                 <br>
        </div>
        </div>
        </div>
        
       
        @yield('conteudo')
        </div>
        </div>
        <hr>
        @yield('rodapé')

        
        
       
      <br>
        </main>
     <div class="text-center">
        <footer class="container">
        <p>&copy;Companhia GPSI 2020-2021</p>
        </footer>
    </div>
    
    

    </body>
</html>