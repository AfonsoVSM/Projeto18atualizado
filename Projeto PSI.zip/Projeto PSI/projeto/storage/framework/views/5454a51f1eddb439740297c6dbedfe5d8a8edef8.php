
ID:<?php echo e($requisicao->id_requisicao); ?><br>
Titulo:<?php echo e($requisicao->observacoes); ?><br>
<h1><i>Requisitantes:</h1></i>
<?php $__currentLoopData = $requisicao->requisitantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisitante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h2> Nome: </h2>
<h5><?php echo e($requisitante->nome); ?></h5>
<h2> Telefone: </h2>
<h5><?php echo e($requisitante->telefone); ?></h5>
<h2>Email: </h2>
<h5><?php echo e($requisitante->email); ?></h5>
<h2> Localidade: </h2>
<h5><?php echo e($requisitante->localidade); ?></h5>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






	<?php /**PATH C:\Users\avale\Desktop\Projeto PSI\projeto\resources\views/requisicoes/show.blade.php ENDPATH**/ ?>