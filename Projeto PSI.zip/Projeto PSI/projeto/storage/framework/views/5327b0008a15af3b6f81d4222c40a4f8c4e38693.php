
<?php $__env->startSection('nabvar'); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

<ul>
<?php $__currentLoopData = $requisicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('requisicoes.show', ['id'=>$requisicao->id_requisicao])); ?>">
 <?php echo e($requisicao->observacoes); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($requisicoes->render()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\avale\Desktop\Projeto PSI\projeto\resources\views/requisicoes/index.blade.php ENDPATH**/ ?>