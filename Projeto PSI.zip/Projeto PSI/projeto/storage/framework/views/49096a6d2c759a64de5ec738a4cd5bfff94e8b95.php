
<?php $__env->startSection('nabvar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

ID:<?php echo e($requisicao->id_requisicao); ?><br>
Titulo:<?php echo e($requisicao->observacoes); ?><br>
<h1><i>Requisitantes:</h1></i>
<?php $__currentLoopData = $requisicao->requisitantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisitante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h2> Nome: </h2>
<h5><?php echo e($requisitante->nome); ?></h5>
<h2> Telefone: </h2>
<h5><?php echo e($requisitante->telefone); ?></h5>
<h2>Email: </h2>
<h5><?php echo e($requisitante->email); ?></h5>
<h2> Localidade: </h2>
<h5><?php echo e($requisitante->localidade); ?></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>





	
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projeto PSI\projeto\resources\views/requisicoes/show.blade.php ENDPATH**/ ?>