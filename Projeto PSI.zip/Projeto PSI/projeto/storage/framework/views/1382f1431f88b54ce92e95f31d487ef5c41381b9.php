

ID:<?php echo e($material->id_material); ?><br>
Titulo:<?php echo e($material->designacao); ?><br>

<h1>Requisicoes:</h1>

<?php $__currentLoopData = $material->requisicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1> Hora de requisicao: </h1>
<?php echo e($requisicao->hora_requisicao); ?>

<h1> hora de entrega: </h1>
<?php echo e($requisicao->hora_entrega); ?>

<h1> Observacoes: </h1>
<?php echo e($requisicao->observacoes); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




	<?php /**PATH C:\Users\avale\Desktop\Projeto PSI\projeto\resources\views/materiais/show.blade.php ENDPATH**/ ?>