
<?php $__env->startSection('nabvar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
ID:<?php echo e($material->id_material); ?><br>
Titulo:<?php echo e($material->designacao); ?><br>

<h1>Requisicoes:</h1>

<?php $__currentLoopData = $material->requisicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1> Hora de requisicao: </h1>
<?php echo e($requisicao->hora_requisicao); ?>

<h1> hora de entrega: </h1>
<?php echo e($requisicao->hora_entrega); ?>

<h1> Observacoes: </h1>
<?php echo e($requisicao->observacoes); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projeto PSI\projeto\resources\views/materiais/show.blade.php ENDPATH**/ ?>