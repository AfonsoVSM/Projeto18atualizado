ID:<?php echo e($material->id_material); ?><br>
Titulo:<?php echo e($material->designacao); ?><br>

<i>Requisicoes:</i>

<?php $__currentLoopData = $material->requisicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h2> Data de requisicao: </h2>
<h5><?php echo e($requisicao->data_requisicao); ?></h5>
<h2> Data de entrega: </h2>
<h5><?php echo e($requisicao->data_entrega); ?></h5>
<h2> Observacoes: </h2>
<h5><?php echo e($requisicao->observacoes); ?></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php /**PATH C:\Users\Paulo Costa\Desktop\Projeto PSI\projeto\resources\views/materiais/show.blade.php ENDPATH**/ ?>