<b>ID:</b><?php echo e($requisitante->id_requisitante); ?><br>
<br>
<b>Nome:</b><?php echo e($requisitante->nome); ?><br>
<br>
<b>Telefone:</b><?php echo e($requisitante->telefone); ?><br>
<br>
<b>Email:</b><?php echo e($requisitante->email); ?><br>
<br>
<b>Localidade:</b><?php echo e($requisitante->localidade); ?><br>
<br>
<b>Cartao_Cidadao:</b><?php echo e($requisitante->cartao_cidadao); ?><br>
<br>
<h1><i>Tipos de Equipamentos:</b></h1></i>
<h1>Computadores</h1>

<?php /**PATH C:\Users\avale\Desktop\Projeto PSI\projeto\resources\views/requisitantes/show.blade.php ENDPATH**/ ?>