<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Requisitantes;
class TiposEquipsController extends Controller
{
    //
           public function index(){

    $tipo_equipamento= TipoEquip::paginate(4);

    return view ('tipos_equipamentos.index', ['tipos_equipamentos'=>$tipos_equipamentos]);
}
public function show (Request $request){
    $idTipoEquip=$request->id;

    $tipos_equipamentos=TiposEquips::where('id_tipos_equipamentos', $idTipoEquip)->with('tipos_equipamentos')->first();

    return view ('tipos_equipamentos.show',['tipos_equipamentos'=>$tipos_equipamentos]);
}
}